﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafariModel.Model.Tiles
{
    public enum TileCondition
    {
        EMPTY,IS_ROAD,IS_SMALL_BRIDGE,IS_LARGE_BRIDGE
    }
}
