﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafariModel.Model.Tiles
{
    public enum TileType
    {
        EMPTY, HILL, GROUND ,WATER, ENTRANCE, EXIT, FENCE, GRASS_GROUND
    }
}
